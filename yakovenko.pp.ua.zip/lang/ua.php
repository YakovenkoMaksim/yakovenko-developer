<?php
return array(
    'lng.test' => 'Приклад тексту',
);