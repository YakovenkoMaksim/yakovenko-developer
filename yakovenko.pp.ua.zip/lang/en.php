<?php
return array(
    'lng.test' => 'Sample text',
); 